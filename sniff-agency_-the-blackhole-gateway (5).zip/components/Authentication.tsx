import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { gsap } from 'gsap';

interface AuthenticationProps {
  onAuthSuccess: () => void;
}

const lineVertexShader = `
    varying float vProgress;
    void main() {
        // Assuming the tube is oriented along an axis, we can use one of the coordinates for progress.
        // This is a simplification; a more robust method uses UVs if the geometry supports it.
        // For a CatmullRomCurve3, the vertex order is sequential.
        vProgress = position.y; // This might need adjustment based on curve orientation
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;

const lineFragmentShader = `
    uniform float uProgress;
    uniform vec3 uColor;
    varying float vProgress;

    void main() {
        // This is a simple progress check. If using UVs, you'd check uv.x or uv.y.
        // The value '10.0' is a magic number based on the curve's height, adjust as needed.
        if (vProgress > uProgress * 20.0 - 10.0) {
            discard;
        }
        float alpha = pow(1.0 - gl_FragCoord.z, 4.0);
        gl_FragColor = vec4(uColor, alpha);
    }
`;

const billboardVertexShader = `
    varying vec2 vUv;
    void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;
const billboardFragmentShader = `
    varying vec2 vUv;
    uniform float uOpacity;
    uniform float uTime;

    float rand(vec2 n) { 
        return fract(sin(dot(n, vec2(12.9898, 4.1414))) * 43758.5453);
    }

    void main() {
        // Frame
        vec2 innerMin = vec2(0.02);
        vec2 innerMax = vec2(0.98);
        float borderDist = min(
            min(vUv.x - innerMin.x, innerMax.x - vUv.x),
            min(vUv.y - innerMin.y, innerMax.y - vUv.y)
        );
        
        float frame = smoothstep(0.0, 0.005, borderDist) - smoothstep(0.01, 0.015, borderDist);
        vec3 frameColor = vec3(0.5, 1.0, 1.0) * frame;

        // Background
        float noise = rand(vUv * uTime * 0.1);
        vec3 bgColor = vec3(0.1, 0.2, 0.3) * (0.2 + noise * 0.1);

        // Scanlines
        float scanline = sin(vUv.y * 300.0 + uTime) * 0.04;
        bgColor += scanline;

        vec3 finalColor = frameColor + bgColor;

        gl_FragColor = vec4(finalColor, uOpacity * (frame + 0.2));
    }
`;


const Authentication: React.FC<AuthenticationProps> = ({ onAuthSuccess }) => {
    const mountRef = useRef<HTMLDivElement>(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const uiRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!mountRef.current) return;
        const currentMount = mountRef.current;

        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 0, 15);

        const listener = new THREE.AudioListener();
        camera.add(listener);
        const sound = new THREE.PositionalAudio(listener);
        const audioLoader = new THREE.AudioLoader();
        audioLoader.load('https://assets.codepen.io/217233/space_ambient.mp3', function(buffer) {
            sound.setBuffer(buffer);
            sound.setLoop(true);
            sound.setVolume(0.5);
            sound.setRefDistance(5);
            sound.play();
        });

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        currentMount.appendChild(renderer.domElement);

        // Vortex Particles
        const particleCount = 10000;
        const positions = new Float32Array(particleCount * 3);
        const velocities = [];
        const baseColor = new THREE.Color(0x6100ff);
        const accentColor = new THREE.Color(0x00ffff);
        const colors = new Float32Array(particleCount * 3);

        for (let i = 0; i < particleCount; i++) {
            const i3 = i * 3;
            const radius = 2 + Math.random() * 8;
            const angle = Math.random() * Math.PI * 2;
            positions[i3] = Math.cos(angle) * radius;
            positions[i3 + 1] = (Math.random() - 0.5) * 5;
            positions[i3 + 2] = Math.sin(angle) * radius;
            velocities.push(new THREE.Vector3());
            const mixedColor = baseColor.clone().lerp(accentColor, Math.random() * 0.5);
            colors[i3] = mixedColor.r;
            colors[i3 + 1] = mixedColor.g;
            colors[i3 + 2] = mixedColor.b;
        }

        const particleGeometry = new THREE.BufferGeometry();
        particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        const particleMaterial = new THREE.PointsMaterial({ size: 0.03, vertexColors: true, blending: THREE.AdditiveBlending, transparent: true, opacity: 0.7 });
        const vortex = new THREE.Points(particleGeometry, particleMaterial);
        vortex.add(sound);
        scene.add(vortex);

        // Energy Line
        const curve = new THREE.CatmullRomCurve3([
            new THREE.Vector3(0, -10, 0),
            new THREE.Vector3(0, -5, 1),
            new THREE.Vector3(2, 0, 5),
            new THREE.Vector3(-3, 3, 7),
            new THREE.Vector3(0, 5, 9),
            new THREE.Vector3(0, 5, 10)
        ]);
        const tubeGeometry = new THREE.TubeGeometry(curve, 64, 0.05, 8, false);
        const tubeMaterial = new THREE.ShaderMaterial({
            vertexShader: lineVertexShader,
            fragmentShader: lineFragmentShader,
            uniforms: {
                uProgress: { value: 0 },
                uColor: { value: new THREE.Color(0x00ffff) }
            },
            transparent: true,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });
        const energyLine = new THREE.Mesh(tubeGeometry, tubeMaterial);
        scene.add(energyLine);

        // Billboard
        const billboardGeometry = new THREE.PlaneGeometry(5, 3);
        const billboardMaterial = new THREE.ShaderMaterial({
            vertexShader: billboardVertexShader,
            fragmentShader: billboardFragmentShader,
            uniforms: {
                uOpacity: { value: 0.0 },
                uTime: { value: 0.0 }
            },
            transparent: true,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide
        });
        const billboard = new THREE.Mesh(billboardGeometry, billboardMaterial);
        billboard.position.set(0, 5, 10);
        billboard.scale.set(0, 0, 0);
        scene.add(billboard);

        const composer = new EffectComposer(renderer);
        composer.addPass(new RenderPass(scene, camera));
        const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.2, 0.6, 0.8);
        composer.addPass(bloomPass);

        const clock = new THREE.Clock();
        const animate = () => {
            requestAnimationFrame(animate);
            const delta = clock.getDelta();
            const elapsedTime = clock.getElapsedTime();
            billboardMaterial.uniforms.uTime.value = elapsedTime;

            const posAttr = vortex.geometry.getAttribute('position') as THREE.BufferAttribute;
            for (let i = 0; i < particleCount; i++) {
                const i3 = i * 3;
                const p = new THREE.Vector3(posAttr.getX(i), posAttr.getY(i), posAttr.getZ(i));
                const radius = Math.sqrt(p.x * p.x + p.z * p.z);
                const angle = Math.atan2(p.z, p.x);
                const newAngle = angle + (delta * 2 / (radius + 0.1));
                p.x = Math.cos(newAngle) * radius * (1 - delta * 0.1);
                p.z = Math.sin(newAngle) * radius * (1 - delta * 0.1);
                p.y -= delta * 0.5;

                if (p.length() < 0.5 || p.y < -10) {
                    const r = 2 + Math.random() * 8;
                    const a = Math.random() * Math.PI * 2;
                    p.x = Math.cos(a) * r;
                    p.y = 5 + (Math.random() - 0.5) * 5;
                    p.z = Math.sin(a) * r;
                }
                posAttr.setXYZ(i, p.x, p.y, p.z);
            }
            posAttr.needsUpdate = true;
            vortex.rotation.y += delta * 0.1;
            composer.render();
        };
        animate();

        const handleResize = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        };
        window.addEventListener('resize', handleResize);

        const playAudio = () => {
             if (listener.context.state === 'suspended') {
                listener.context.resume();
            }
            window.removeEventListener('pointerdown', playAudio);
        };
        window.addEventListener('pointerdown', playAudio);
        
        setIsLoaded(true);

        gsap.timeline({
            onComplete: () => {
                if(uiRef.current) {
                    uiRef.current.style.opacity = '1';
                    uiRef.current.style.pointerEvents = 'auto';
                }
            }
        })
        .from(camera.position, { z: 40, duration: 4, ease: 'power2.out' }, 0)
        .to(camera.rotation, { y: -Math.PI / 8, duration: 4, ease: 'power2.out' }, 0)
        .to(tubeMaterial.uniforms.uProgress, { value: 1.0, duration: 2.5, ease: 'power2.inOut' }, 1)
        .to(billboard.scale, { x: 1, y: 1, z: 1, duration: 1.5, ease: 'elastic.out(1, 0.7)' }, 2.8)
        .to(billboard.material.uniforms.uOpacity, { value: 1.0, duration: 1.0 }, 2.8);


        return () => {
            window.removeEventListener('resize', handleResize);
            window.removeEventListener('pointerdown', playAudio);
            if (sound?.isPlaying) sound.stop();
            currentMount.removeChild(renderer.domElement);
        };
    }, []);
    
    const handleConnect = () => {
        if (uiRef.current) {
            gsap.to(uiRef.current, {
                opacity: 0,
                duration: 0.5,
                onComplete: onAuthSuccess
            });
        } else {
            onAuthSuccess();
        }
    };

    return (
        <div className="relative w-full h-full">
            <div ref={mountRef} className={`absolute top-0 left-0 w-full h-full transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`} />
             <div ref={uiRef} className="absolute inset-0 flex items-center justify-center p-8 opacity-0 pointer-events-none transition-opacity duration-500" style={{ top: '15%'}}>
                <div className="text-center flex flex-col items-center gap-6">
                    <h1 className="text-4xl md:text-5xl font-bold text-cyan-100" style={{ fontFamily: "'Space Grotesk', sans-serif", textShadow: '0 0 15px #0ff' }}>
                        AUTHENTICATION REQUIRED
                    </h1>
                    <p className="text-lg md:text-xl max-w-md text-cyan-200 opacity-80">
                        The singularity has transmitted an authorization request. Connect to proceed to the dashboard.
                    </p>
                    <button
                        onClick={handleConnect}
                        className="mt-4 px-10 py-4 border-2 border-cyan-300 text-cyan-300 rounded-full text-xl font-bold uppercase tracking-widest
                                   transform hover:scale-105 hover:bg-cyan-300 hover:text-black hover:shadow-[0_0_25px_#0ff] transition-all duration-300"
                    >
                        Connect Wallet
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Authentication;
