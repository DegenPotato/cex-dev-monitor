
import React from 'react';

interface DashboardProps {
  onReturn: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onReturn }) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-black p-8 text-white">
      <div className="text-center border-2 border-fuchsia-500 rounded-lg p-10 shadow-[0_0_30px_#f0f,inset_0_0_20px_#f0f]">
        <h1 
            className="text-4xl md:text-6xl font-bold mb-4 uppercase"
            style={{ fontFamily: "'Space Grotesk', sans-serif", textShadow: '0 0 10px #fff, 0 0 20px #f0f, 0 0 30px #f0f' }}
        >
            Welcome to the Dashboard
        </h1>
        <p 
            className="text-lg md:text-xl mb-8 text-fuchsia-300"
            style={{ fontFamily: "'Space Grotesk', sans-serif", textShadow: '0 0 5px #f0f' }}
        >
            The Cryptoverse awaits your command.
        </p>

        <div className="max-w-2xl mx-auto bg-gray-900/50 p-6 rounded-md border border-fuchsia-700">
            <h2 className="text-2xl font-semibold mb-4 text-cyan-300">System Status</h2>
            <p className="text-gray-300">All systems operational. Data streams are stable. Awaiting your next query.</p>
        </div>

        <button
          onClick={onReturn}
          className="mt-12 px-8 py-3 border-2 border-fuchsia-500 text-fuchsia-400 rounded-full text-lg font-bold uppercase tracking-widest
                     transform hover:scale-105 hover:bg-fuchsia-500 hover:text-black hover:shadow-[0_0_25px_#f0f] transition-all duration-300"
        >
          Return to Gateway
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
