import React, { useState, useEffect } from 'react';
import ThreeScene from './components/ThreeScene';
import Authentication from './components/Authentication';
import Dashboard from './components/Dashboard';

enum ViewState {
  Landing,
  Authentication,
  Dashboard,
}

function App() {
  const [view, setView] = useState<ViewState>(ViewState.Landing);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [isReturning, setIsReturning] = useState<boolean>(false);

  const handleEnterAuth = () => {
    setIsReturning(false);
    setIsTransitioning(true);
    setTimeout(() => {
      setView(ViewState.Authentication);
      setIsTransitioning(false);
    }, 1000); // 1s fade-out to auth
  };
  
  const handleAuthSuccess = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      setView(ViewState.Dashboard);
      setIsTransitioning(false);
    }, 1000); // 1s fade-out to dashboard
  }

  const handleReturnToGateway = () => {
    setIsReturning(true);
    setIsTransitioning(true);
    setTimeout(() => {
        setView(ViewState.Landing);
        setIsTransitioning(false);
    }, 1000);
  };

  return (
    <main className="w-screen h-screen bg-black text-white overflow-hidden">
      <div className={`w-full h-full transition-opacity duration-1000 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
        {view === ViewState.Landing && <ThreeScene onEnter={handleEnterAuth} isReturning={isReturning} />}
        {view === ViewState.Authentication && <Authentication onAuthSuccess={handleAuthSuccess} />}
        {view === ViewState.Dashboard && <Dashboard onReturn={handleReturnToGateway} />}
      </div>
    </main>
  );
}

export default App;
